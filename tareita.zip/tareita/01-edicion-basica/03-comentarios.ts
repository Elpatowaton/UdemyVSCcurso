/*
    Objetivo:
        comentar un bloque de código

    Tips:
        Ctrl + /
*/

const a = 10;
const b = 20;
const c = 30;
const d = {a, b, c};

// const a = 10;
// const b = 20;
// const c = 30;
// const d = { a, b, c};


console.log( a, b, c, d);

// Resultado final
// Sólo dejar un bloque comentado
// Done!!