/*
    Objetivo:
        Deshacer y rehacer el código
§
    Tips:
        Ctrl +Z
        Ctrl + Shift + Z

*/

function oaworld(){
    return 'oa!'
}




// Demo
// function oaworld() {
//     return 'oa!';
// }


// Done!!