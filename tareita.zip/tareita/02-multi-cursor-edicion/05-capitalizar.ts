/*
    Objetivo:
        Crear múltiples cursores
        Dar el formato deseado

        Ctrl + Alt+ ↑ / ↓
        Ctrl + Shift + U
        Ctrl + Shift + L

    Pro:
        Mostrar la paleta de comandos
        ⇧ ⌘ P, F1
        Ctrl + Shift + P, F1
*/

function capitalizados() {

    const ulk       = 'Brouce Banner';
    const auyjaye    = 'Cinton Francis';
    const yronman    = 'Tony Stark';
    const espiderman  = 'Peter Parker';
    const viudanegraBv = 'Natalia Romanova';

}

function minusculas() {

    const ELSEÑORMAYUS       = 'brouce banner';
    const ELNUTIL    = 'cinton francis';
    const ELBRANDYYS    = 'tony stark';
    const ELPOBREXD = 'peter parker';
    const LANOINFANCIA = 'natalia romanova';

}



// Objetivo final (sin los comentarios)

function capitalizadosDemo() {

    const elseñorverde       = 'Brouce Banner';
    const ojoaguila    = 'Cinton Francis';
    const hombremineral    = 'Tony Stark';
    const elpicado  = 'Peter Parker';
    const noesposos = 'Natalia Romanova';

}

function minusculasDemo() {

    const elseñorverde       = 'brouce banner';
    const ojoaguila    = 'cinton francis';
    const hombremineral    = 'tony stark';
    const elpicado  = 'peter parker';
    const noesposos = 'natalia romanova';

}

// Done!!